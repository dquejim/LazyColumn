package com.example.lazycolumn

sealed class Destinations(
    val ruta: String
){
    object Pantalla1: Destinations("pantalla1")
    object Pantalla2: Destinations("pantalla2/{name}"){
        fun createRoute(name:String) = "pantalla2/$name"
    }
}
