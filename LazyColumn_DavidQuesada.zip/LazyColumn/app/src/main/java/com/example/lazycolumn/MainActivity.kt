package com.example.lazycolumn

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.example.lazycolumn.ui.theme.LazyColumnTheme
import com.example.lazycolumn.modelos.Peliculas
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.Button
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.em
import coil.compose.rememberImagePainter
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LazyColumnTheme {
                // A surface container using the 'background' color from the theme
                Surface(color = Color.LightGray) {
                    NavigationHost()
                }
            }
        }
    }
}

fun getLista(): List<Peliculas>{

    val listaPeliculas = listOf(
        Peliculas("Nosferatu","Terror", "El joven Hutter y su mujer Ellen viven felices en la ciudad de Wisborg, hasta que un extraño agente inmobiliario llamado Knock decide enviar a Hutter a Transilvania para cerrar un negocio con el conde Orlok. Se trata de la venta de finca en Wisborg que linda con la casa de Hutter.","http://cdn.shopify.com/s/files/1/1801/1563/files/Nosferatu_grande.jpg?v=1539110662"),
        Peliculas("Iron Man","Acción/Superpoderes","Anthony Stark, un multimillonario industrial y genio inventor es secuestrado y obligado a construir un arma devastadora. En su lugar, utilizando su inteligencia e ingenio, Anthony construye una armadura de alta tecnología y escapa de su cautiverio.","https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/iron-man-1-1554387074.jpg"),
        Peliculas("Hallowen Kills","Terror","La noche de Halloween en la que Michael Myers regresa no ha acabado todavía. Minutos después de que Laurie Strode, su hija Karen y su nieta Allyson dejen encerrado y ardiendo a este monstruo enmascarado, Laurie se dirige rápidamente al hospital para tratar sus heridas, creyendo que todo ha terminado. ","https://static3.elcorreo.com/www/multimedia/202110/21/media/cortadas/halloween-kills%20(2)-kLnD-U150901765999pJE-1248x770@RC.jpg"),
        Peliculas("Ejercito de no muertos","Acción","Un grupo de mercenarios decide llevar a cabo el mayor atraco que jamás se haya realizado en la ciudad de Las Vegas justo después de que se produzca una epidemia de muertos vivientes.","https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/ejercito-de-los-muertos-1-1621678570.jpg"),
        Peliculas("Confinados","Comedia/Actualidad","Linda (Anne Hathaway) y Paxton (Chiwetel Ejiofor) son una pareja con problemas pero que deciden pausar su separación con un objetivo: aprovecharse del confinamiento por la pandemia mundial e intentar llevar a cabo un robo de joyas en los almacenes Harrods.","https://d9u8u3s4.rocketcdn.me/wp-content/uploads/2021/02/confinados-pelicula-hbo-2-1155x720.jpg"),
        Peliculas("Free Guy","Comedia/Ciencia Ficción","Guy (Ryan Reynolds) trabaja como cajero de un banco, y es un tipo alegre y solitario al que nada la amarga el día. Incluso si le utilizan como rehén durante un atraco a su banco, él sigue sonriendo como si nada. Pero un día se da cuenta de que Free City no es exactamente la ciudad que él creía. Guy va a descubrir que en realidad es un personaje no jugable dentro de un brutal videojuego","https://gcdn.lanetaneta.com/wp-content/uploads/2021/08/Se-revela-la-fecha-de-lanzamiento-de-Free-Guy-Blu-ray.jpg"),
        Peliculas("Eternals","Ciencia ficción/Superpoderes","Hace millones de años, los seres cósmicos conocidos como los Celestiales comenzaron a experimentar genéticamente con los humanos. Su intención era crear individuos superpoderosos que hicieran únicamente el bien, pero algo salió mal y aparecieron los Desviantes, destruyendo y creando el caos a su paso. ","https://phantom-marca.unidadeditorial.es/c43091bf01eff76a5c3b71248f61ad65/resize/1320/f/jpg/assets/multimedia/imagenes/2021/11/05/16361009177455.jpg")
    )

    return listaPeliculas
}



@Composable
fun Pantalla1(navController: NavController) {

    LazyColumn(
        contentPadding = PaddingValues(10.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
        )
    {
        items(getLista()) { pelicula ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = {
                        navController.navigate(
                            Destinations.Pantalla2.createRoute(
                                pelicula.titulo
                            )
                        )
                    })

            ){
                    CargarImagen(url = pelicula.imagen)
                }
            }
        }
    }

@Composable
fun Pantalla2(Nombre:String,navController: NavController) {
    val listaPeliculas = getLista()
    var peliculaSeleccionada : Peliculas = Peliculas("1","1","1","1")

    for (pelicula in listaPeliculas){
        if (pelicula.titulo == Nombre){
            peliculaSeleccionada = pelicula
        }
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight()
            .background(color = Color.LightGray)
            .padding(24.dp)
    ) {


        Row(modifier = Modifier
            .background(color = Color.Gray)
            .fillMaxWidth()
            .padding(start = 10.dp)){
            Text(text = peliculaSeleccionada.titulo,fontStyle = FontStyle.Italic,fontWeight = FontWeight.Bold,fontSize = 30.sp,lineHeight = 2.em)
        }

        Row(modifier = Modifier
            .padding(bottom = 20.dp,top = 10.dp)
        ) {
            CargarImagen(url = peliculaSeleccionada.imagen)
        }


        Row{
            Text(text = "("+peliculaSeleccionada.genero+")\n",fontStyle = FontStyle.Italic,fontWeight = FontWeight.Bold,fontSize = 20.sp,lineHeight = 2.em)
        }

        Row{
            Text(text = peliculaSeleccionada.descripcion,lineHeight = 2.em,textAlign = TextAlign.Center)
        }

        Button(onClick = {navController.navigate(Destinations.Pantalla1.ruta)},modifier = Modifier.padding(top = 45.dp)) {
            Text(text = "Volver")
        }
    }
}

@Composable
fun NavigationHost(){
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = Destinations.Pantalla1.ruta){
        composable(Destinations.Pantalla1.ruta){
            Pantalla1(navController = navController)
        }

        composable(Destinations.Pantalla2.ruta){ navBackStackEntry ->
            var Nombre = navBackStackEntry.arguments?.getString("name")
            Pantalla2(Nombre!!,navController = navController)
        }
    }

}

@Composable
fun CargarImagen(url: String) {
    Image(
        painter = rememberImagePainter(url),
        contentDescription = "Imagen",
        modifier = Modifier
            .fillMaxWidth()
            .padding(10.dp)
            .height(150.dp)
            .clip(RoundedCornerShape(100.dp)),
        contentScale = ContentScale.FillWidth

    )
}