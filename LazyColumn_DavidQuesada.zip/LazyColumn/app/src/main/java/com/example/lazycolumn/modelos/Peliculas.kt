package com.example.lazycolumn.modelos

data class Peliculas(val titulo: String,val genero: String, val descripcion: String,val imagen: String)